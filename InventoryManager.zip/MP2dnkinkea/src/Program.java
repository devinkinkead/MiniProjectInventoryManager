// Devin Kinkead
public class Program {
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		InventorySystem invSys = new InventorySystem();
		
		invSys.showMenu();
		
		
		
		
	} // Main

	

	
	
	
} // Program
